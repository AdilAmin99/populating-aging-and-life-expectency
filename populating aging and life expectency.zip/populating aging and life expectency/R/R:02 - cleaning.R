
# ============================================================
# R/02_clean.R
# PROJECT: Population Ageing and Life Expectancy in the EU
# PERIOD: 2010–2024
# COUNTRIES: EU-27
# ============================================================

# STEP 1: LOAD PACKAGES AND RAW DATA

library(tidyverse)
library(here)

source("R/R:01 - importing csv files.R")


# STEP 2: INSPECT RAW DATA

glimpse(life)
glimpse(pop)

count(life, sex, age, unit, sort = TRUE)
count(pop, sex, age, unit, sort = TRUE)

sum(is.na(life$values))
sum(is.na(pop$values))


# STEP 3: DEFINE EU-27 COUNTRIES

eu27 <- c(
  "AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI",
  "FR", "DE", "EL", "HU", "IE", "IT", "LV", "LT", "LU",
  "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE"
)


# ============================================================
# STEP 4: CLEAN LIFE EXPECTANCY DATA
# ============================================================

# Keep Total, Female and Male observations
# Preserve original Eurostat observation flags

life_clean <- life %>%
  filter(
    geo %in% eu27,
    time >= 2010,
    time <= 2024,
    age == "Y_LT1",
    unit == "YR",
    freq == "A",
    sex %in% c("T", "F", "M")
  ) %>%
  transmute(
    geo,
    year = as.integer(time),
    sex,
    life_expectancy = values,
    life_flag = OBS_FLAG
  )

# Check life expectancy data

stopifnot(
  !anyNA(life_clean$life_expectancy),
  !anyDuplicated(life_clean[c("geo", "year", "sex")])
)

# Extract total life expectancy for main analysis

life_total <- life_clean %>%
  filter(sex == "T") %>%
  select(geo, year, life_expectancy)

stopifnot(
  nrow(life_total) == 405,
  !anyDuplicated(life_total[c("geo", "year")])
)


# ============================================================
# STEP 5: CALCULATE POPULATION AGED 65+
# ============================================================

ages65 <- c(paste0("Y", 65:99), "Y_OPEN")

pop_use <- pop %>%
  filter(
    geo %in% eu27,
    time >= 2010,
    time <= 2024,
    sex == "T",
    unit == "NR",
    freq == "A"
  )

# Check duplicates

stopifnot(
  !anyDuplicated(pop_use[c("geo", "time", "age")])
)


# STEP 6: TOTAL POPULATION

pop_total <- pop_use %>%
  filter(age == "TOTAL") %>%
  transmute(
    geo,
    year = as.integer(time),
    population_total = values
  )


# STEP 7: POPULATION AGED 65+

pop_old <- pop_use %>%
  filter(age %in% ages65) %>%
  group_by(geo, time) %>%
  summarise(
    n_open = sum(age == "Y_OPEN"),
    last_age = max(
      as.integer(
        sub("Y", "", age[age != "Y_OPEN"])
      )
    ),
    n_ages = n(),
    population_65plus = sum(values),
    .groups = "drop"
  )

# Validate age categories and population values

stopifnot(
  all(pop_old$n_open == 1),
  all(pop_old$n_ages == pop_old$last_age - 65 + 2),
  !anyNA(pop_old$population_65plus)
)

# Keep required columns

pop_old <- pop_old %>%
  transmute(
    geo,
    year = as.integer(time),
    population_65plus
  )


# ============================================================
# STEP 8: CALCULATE AGEING PERCENTAGE
# ============================================================

ageing <- inner_join(
  pop_total,
  pop_old,
  by = c("geo", "year"),
  relationship = "one-to-one"
) %>%
  mutate(
    age65_share = 100 * population_65plus /
      population_total
  )

stopifnot(
  nrow(ageing) == 405,
  all(!is.na(ageing$population_total)),
  all(ageing$population_total > 0),
  all(!is.na(ageing$age65_share)),
  all(ageing$age65_share >= 0 &
        ageing$age65_share <= 100)
)


# ============================================================
# STEP 9: COMBINE LIFE EXPECTANCY AND AGEING
# ============================================================

combined <- inner_join(
  life_total,
  ageing,
  by = c("geo", "year"),
  relationship = "one-to-one"
) %>%
  filter(
    !is.na(life_expectancy),
    !is.na(age65_share)
  )


# ============================================================
# STEP 10: VERIFY COMPLETE EU-27 PANEL
# ============================================================

expected <- expand_grid(
  geo = eu27,
  year = 2010:2024
)

missing_rows <- anti_join(
  expected,
  combined,
  by = c("geo", "year")
)

print(missing_rows)

stopifnot(
  nrow(missing_rows) == 0,
  nrow(combined) == 405,
  !anyDuplicated(combined[c("geo", "year")])
)

print(combined %>% count(geo))
print(summary(combined))


# ============================================================
# STEP 11: PRESERVE POPULATION FLAGS
# ============================================================

# Keep flagged population observations used in analysis

pop_flags <- pop_use %>%
  filter(
    age %in% c("TOTAL", ages65),
    !is.na(OBS_FLAG)
  )

# Check flags

print(pop_flags %>% count(OBS_FLAG))


# ============================================================
# STEP 12: SAVE PROCESSED DATASETS
# ============================================================

dir.create(
  here("data", "processed"),
  recursive = TRUE,
  showWarnings = FALSE
)

# Main analysis dataset

write_csv(
  combined,
  here("data", "processed", "analysis.csv")
)

# Life expectancy data: T, F, M and life_flag

write_csv(
  life_clean,
  here("data", "processed", "life_clean.csv")
)

# Population flag records

write_csv(
  pop_flags,
  here("data", "processed", "population_flags.csv")
)


# ============================================================
# STEP 13: FINAL VERIFICATION
# ============================================================

cat("\n--- CLEANING COMPLETE ---\n")

cat("Life expectancy rows:", nrow(life_clean), "\n")
cat("Combined analysis rows:", nrow(combined), "\n")
cat("Population flagged rows:", nrow(pop_flags), "\n")

cat("\nLife expectancy columns:\n")
print(names(life_clean))

cat("\nCombined dataset columns:\n")
print(names(combined))

cat("\nProcessed files:\n")
print(list.files(here("data", "processed")))

cat("\nAll validation checks passed.\n")
