#importing data into R
library(readr)
library(dplyr)
#setting path relative to working directory

life_path <- file.path(
  "data", "raw", "estat_demo_mlexpec_filtered_en.csv"
)


pop_path <- file.path("data", "raw", 
                      "estat_demo_pjan_filtered_en.csv")

#check files
file.exists(life_path)
file.exists(pop_path)


stopifnot(file.exists(life_path), file.exists(pop_path))
### since. both files exist now we'll continue with the data

###define coulms types


csv_types <- cols(
  .default = col_character(),
  TIME_PERIOD = col_integer(),
  OBS_VALUE = col_double()
)


### IMPORT DARASETS

life <- read_csv(
  life_path, col_types = csv_types,
  na = c("", ":", "NA"),
  show_col_types = FALSE
)
  
pop <- read_csv(
  pop_path, col_types = csv_types,
  na = c("",":", "NA"),
  show_col_types = FALSE
)
  
  
###5: CHECK FOR IMPORT PROBLEMS:

stop_for_problems(life)
stop_for_problems(pop)


###STEP 06:  VERIFYING REQUIRED COULMNS


required <- c(
  "geo", "sex", "age", "unit", "freq", 
  "TIME_PERIOD", "OBS_VALUE", "OBS_FLAG", "CONF_STATUS"
)
  
  
stopifnot(
  all(required %in% names(life)),
  all(required %in% names(pop))
)

### STEP 07: RENAMING COULMNS TO MATCH IN BOTH DATASETS

life <- life %>%
  rename(
    time = TIME_PERIOD,
    values = OBS_VALUE
  )

pop <- pop %>%
  rename(
    time = TIME_PERIOD,
    values = OBS_VALUE
  )

  
  

### STEP 08: DISPLAYING RESULTS:

cat( "life expectancy rows:", nrow(life), "\n")
cat("population rows:", nrow(pop), "\n")
cat("existing CSV files loaded; raw files unchanged.\n")
  
  
  
  






