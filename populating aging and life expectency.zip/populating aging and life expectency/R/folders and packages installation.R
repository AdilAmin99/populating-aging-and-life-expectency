
folders <- c( "data/raw", "data/procesed", "figures",
              "plots", "R", "report", "results")
#create all folders
for (folder in folders) {
  dir.create(folder, recursive = TRUE, showWarnings = FALSE)
}

#check created folders
list.dirs(".", recursive = TRUE)

#installing required packages

install.packages(c("eurostat", "tidyverse", "broom", "fixest",
                   "modelsummary", "here", "renv", "quarto"
                   ))

