

# STEP 1: WE'LL LOAD PACKAGES

library(tidyverse)
library(here)


# STEP 2: IMPORTING PROCESSED ANALYSIS DATA

dat <- read_csv(
  here("data", "processed", "analysis.csv"),
  show_col_types = FALSE
)

# Verify data
names(dat)
nrow(dat)


# ============================================================
# STEP 3: LIFE EXPECTANCY TREND GRAPH
# ============================================================

selected <- c("IT", "DE", "AT", "FR", "ES")

p1 <- dat %>%
  filter(geo %in% selected) %>%
  ggplot(
    aes(
      x = year,
      y = life_expectancy,
      color = geo
    )
  ) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 1.4) +
  labs(
    title = "Life expectancy at birth",
    subtitle = "Selected EU countries, 2010-2024",
    x = "Year",
    y = "Years",
    color = "Country"
  ) +
  theme_minimal()

# Create figures folder

dir.create(
  here("figures"),
  recursive = TRUE,
  showWarnings = FALSE
)

# Save graph

ggsave(
  here("figures", "life_trends.png"),
  plot = p1,
  width = 9,
  height = 5,
  dpi = 220
)


# ============================================================
# STEP 4: RELOAD LIFE EXPECTANCY DATA FROM R02
# ============================================================

# Do not overwrite the processed CSV here

life_clean <- read_csv(
  here("data", "processed", "life_clean.csv"),
  col_types = cols(
    life_flag = col_character()
  ),
  show_col_types = FALSE
)

# Verify columns

print(names(life_clean))

stopifnot(
  all(
    c("geo", "year", "sex",
      "life_expectancy", "life_flag") %in%
      names(life_clean)
  )
)


# ============================================================
# STEP 5: PREPARE MALE AND FEMALE LIFE EXPECTANCY
# ============================================================

life_wide <- life_clean %>%
  filter(
    sex %in% c("F", "M")
  ) %>%
  select(
    geo,
    year,
    sex,
    life_expectancy
  ) %>%
  pivot_wider(
    names_from = sex,
    values_from = life_expectancy
  )

gap <- life_wide %>% mutate(female_male_gap = F - M)
stopifnot(nrow(gap) == 405, !anyNA(gap$female_male_gap))
summary(gap$female_male_gap)
write_csv(gap, here("data", "processed", "sex_gap.csv"))

# Verify results

print(names(life_wide))
print(nrow(life_wide))
print(head(life_wide))

# Check for missing male/female values

stopifnot(
  !anyNA(life_wide$F),
  !anyNA(life_wide$M)
)



###we'll double-check:
nrow(dat)
# Expected: 405

names(life_clean)
# Expected: geo, year, sex, life_expectancy, life_flag

nrow(life_wide)
# Expected: 405


#==============================
#### NOW WE'LL PERFROM STATISTICAL ANALYSIS 
#==============================

#[ SIMPLE DESCRIPTIVE ASSOCIATION]
library(fixest)
library(broom)
library(dplyr)

combined <- readr::read_csv(here::here("data","processed", "analysis.csv"),
                            show_col_types = FALSE)
m_simple <- lm(life_expectancy ~ age65_share, data = combined)
summary(m_simple)
confint(m_simple)

#[COUNTRY AND YEAR FIXED EFFECTS]


m_fe <- feols(
  life_expectancy ~ age65_share | geo + year,
  data = combined,
  vcov = ~geo
)

summary(m_fe)


model_table <- modelsummary::modelsummary(
  list("simple OLS" = m_simple, "country/year FE" = m_fe),
  output = "data.frame")

print(model_table)


### BASIC DIAGNOSTICS AND SENSTIVITY CHECK

par(mfrow = c(2, 2))
plot(m_simple)
par(mfrow = c(1, 1))

m_without_covid <- feols(
  life_expectancy ~ age65_share | geo + year,
  data = dplyr::filter(combined, !year %in% 2020:2022),
  vcov = ~geo
)

etable(m_fe, m_without_covid)

###SAVING THE PLOTS IN THE FOLDER:

png(
  here("plots", "simple_regression_diagnostics.png"),
  width = 1800,
  height = 1400,
  res = 200
)

par(mfrow = c(2, 2))

plot(m_simple)

dev.off()

par(mfrow = c(1, 1))



file.exists(here("plots", "simple_regression_diagnostics.png"))




# ============================================================
# EU-27 | 2010-2024
# Based on Section 9 of the project guide
# ============================================================

library(tidyverse)
library(here)

# Read saved analysis data
dat <- read_csv(
  here("data", "processed", "analysis.csv"),
  show_col_types = FALSE
)

life_clean <- read_csv(
  here("data", "processed", "life_clean.csv"),
  col_types = cols(life_flag = col_character()),
  show_col_types = FALSE
)

selected <- c("IT", "DE", "AT", "FR", "ES")

dir.create(
  here("figures"),
  recursive = TRUE,
  showWarnings = FALSE
)

# Verify the required input datasets
stopifnot(
  nrow(dat) == 405,
  nrow(life_clean) == 1215,
  !anyNA(dat$life_expectancy),
  !anyNA(dat$age65_share)
)


# ============================================================
# FIGURE 1: LIFE EXPECTANCY TRENDS
#
# Question: How did life expectancy change between
# 2010 and 2024 in selected EU countries?
# ============================================================

p1 <- dat %>%
  filter(geo %in% selected) %>%
  ggplot(
    aes(
      x = year,
      y = life_expectancy,
      color = geo
    )
  ) +
  geom_line(linewidth = 1) +
  geom_point(size = 1.5) +
  scale_x_continuous(breaks = seq(2010, 2024, 2)) +
  labs(
    title = "Life expectancy at birth",
    subtitle = "Italy, Germany, Austria, France and Spain | 2010-2024",
    x = "Year",
    y = "Life expectancy (years)",
    color = "Country",
    caption = "Source: Eurostat, demo_mlexpec"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  here("figures", "01_life_expectancy_trends.png"),
  plot = p1,
  width = 10,
  height = 6,
  dpi = 300
)


# ============================================================
# FIGURE 2: POPULATION AGEING TRENDS
#
# Question: How did the population aged 65+ share
# change between 2010 and 2024?
# ============================================================

p2 <- dat %>%
  filter(geo %in% selected) %>%
  ggplot(
    aes(
      x = year,
      y = age65_share,
      color = geo
    )
  ) +
  geom_line(linewidth = 1) +
  geom_point(size = 1.5) +
  scale_x_continuous(breaks = seq(2010, 2024, 2)) +
  labs(
    title = "Population ageing across selected EU countries",
    subtitle = "Share of population aged 65+ | 2010-2024",
    x = "Year",
    y = "Population aged 65+ (%)",
    color = "Country",
    caption = "Source: Eurostat, demo_pjan; author's calculations"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  here("figures", "02_population_ageing_trends.png"),
  plot = p2,
  width = 10,
  height = 6,
  dpi = 300
)


# ============================================================
# FIGURE 3: EU-27 LIFE EXPECTANCY RANKING IN 2024
#
# Question: Which countries had the highest and
# lowest life expectancy in 2024?
# ============================================================

ranking_2024 <- dat %>%
  filter(year == 2024) %>%
  arrange(desc(life_expectancy))

stopifnot(
  nrow(ranking_2024) == 27,
  !anyDuplicated(ranking_2024$geo)
)

p3 <- ranking_2024 %>%
  ggplot(
    aes(
      x = reorder(geo, life_expectancy),
      y = life_expectancy
    )
  ) +
  geom_col(fill = "steelblue", width = 0.75) +
  geom_text(
    aes(label = round(life_expectancy, 1)),
    hjust = -0.15,
    size = 3
  ) +
  coord_flip(clip = "off") +
  scale_y_continuous(
    limits = c(0, NA),
    expand = expansion(mult = c(0, 0.10))
  ) +
  labs(
    title = "Life expectancy ranking across the EU-27",
    subtitle = "Life expectancy at birth, 2024",
    x = "Country code",
    y = "Life expectancy (years)",
    caption = "Source: Eurostat, demo_mlexpec"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  here("figures", "03_life_expectancy_ranking_2024.png"),
  plot = p3,
  width = 10,
  height = 9,
  dpi = 300
)


# ============================================================
# FIGURE 4: FEMALE-MALE LIFE EXPECTANCY GAP
#
# Question: How large was the female-male gap,
# and how did it change over time?
# ============================================================

life_wide <- life_clean %>%
  filter(sex %in% c("F", "M")) %>%
  select(
    geo, year, sex, life_expectancy
  ) %>%
  pivot_wider(
    names_from = sex,
    values_from = life_expectancy
  )

gap <- life_wide %>%
  mutate(female_male_gap = F - M)

stopifnot(
  nrow(gap) == 405,
  !anyNA(gap$female_male_gap)
)

p4 <- gap %>%
  filter(geo %in% selected) %>%
  ggplot(
    aes(
      x = year,
      y = female_male_gap,
      color = geo
    )
  ) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey60"
  ) +
  geom_line(linewidth = 1) +
  geom_point(size = 1.5) +
  scale_x_continuous(breaks = seq(2010, 2024, 2)) +
  labs(
    title = "Female-male life expectancy gap",
    subtitle = "Selected EU countries | 2010-2024",
    x = "Year",
    y = "Female minus male life expectancy (years)",
    color = "Country",
    caption = "Source: Eurostat, demo_mlexpec; author's calculations"
  ) +
  theme_minimal(base_size = 12)

ggsave(
  here("figures", "04_female_male_life_gap.png"),
  plot = p4,
  width = 10,
  height = 6,
  dpi = 300
)


# ============================================================
# FIGURE 5: AGEING AND LIFE EXPECTANCY ASSOCIATION
#
# Question: What is the descriptive relationship
# between population ageing and life expectancy?
#
# Facet by year to avoid mixing all years
# in one crowded plot.
# ============================================================

p5 <- dat %>%
  ggplot(
    aes(
      x = age65_share,
      y = life_expectancy
    )
  ) +
  geom_point(
    color = "steelblue",
    alpha = 0.75,
    size = 1.8
  ) +
  geom_smooth(
    method = "lm",
    formula = y ~ x,
    se = FALSE,
    color = "firebrick",
    linewidth = 0.7
  ) +
  facet_wrap(~year, ncol = 3) +
  labs(
    title = "Population ageing and life expectancy",
    subtitle = "EU-27 country-year associations, 2010-2024",
    x = "Population aged 65+ (%)",
    y = "Life expectancy at birth (years)",
    caption = paste(
      "Source: Eurostat, demo_mlexpec and demo_pjan.",
      "Descriptive associations; not causal effects."
    )
  ) +
  theme_minimal(base_size = 11)

ggsave(
  here("figures", "05_ageing_life_expectancy_scatter.png"),
  plot = p5,
  width = 13,
  height = 14,
  dpi = 300
)


# ============================================================
# FINAL VERIFICATION: FIVE REQUIRED FIGURES
# ============================================================

figure_files <- c(
  "01_life_expectancy_trends.png",
  "02_population_ageing_trends.png",
  "03_life_expectancy_ranking_2024.png",
  "04_female_male_life_gap.png",
  "05_ageing_life_expectancy_scatter.png"
)

figure_paths <- file.path(
  here("figures"),
  figure_files
)

figure_check <- tibble(
  figure = figure_files,
  saved = file.exists(figure_paths)
)

print(figure_check)

stopifnot(all(figure_check$saved))

cat("\nAll five PDF-required figures have been saved.\n")





# ============================================================
# RESEARCH FINDINGS: DESCRIPTIVE SUMMARY
# ============================================================

# RQ1: Change in population ageing, 2010 to 2024

ageing_change <- dat %>%
  filter(year %in% c(2010, 2024)) %>%
  select(geo, year, age65_share) %>%
  pivot_wider(
    names_from = year,
    values_from = age65_share,
    names_prefix = "y"
  ) %>%
  mutate(
    change_pp = y2024 - y2010
  ) %>%
  arrange(desc(change_pp))

print(ageing_change, n = 27)


# RQ2: Change in life expectancy, 2010 to 2024

life_change <- dat %>%
  filter(year %in% c(2010, 2024)) %>%
  select(geo, year, life_expectancy) %>%
  pivot_wider(
    names_from = year,
    values_from = life_expectancy,
    names_prefix = "y"
  ) %>%
  mutate(
    change_years = y2024 - y2010
  ) %>%
  arrange(desc(change_years))

print(life_change, n = 27)


# RQ3: Countries with largest female-male gaps in 2024

gap_2024 <- gap %>%
  filter(year == 2024) %>%
  arrange(desc(female_male_gap))

print(gap_2024, n = 27)


# RQ4: Life expectancy changes around COVID

covid_change <- dat %>%
  filter(year %in% c(2019, 2021, 2024)) %>%
  select(geo, year, life_expectancy) %>%
  pivot_wider(
    names_from = year,
    values_from = life_expectancy,
    names_prefix = "y"
  ) %>%
  mutate(
    change_2019_2021 = y2021 - y2019,
    change_2019_2024 = y2024 - y2019
  ) %>%
  arrange(change_2019_2021)

print(covid_change, n = 27)


# Save descriptive findings

dir.create(
  here("results"),
  recursive = TRUE,
  showWarnings = FALSE
)

write_csv(
  ageing_change,
  here("results", "ageing_change.csv")
)

write_csv(
  life_change,
  here("results", "life_expectancy_change.csv")
)

write_csv(
  gap_2024,
  here("results", "female_male_gap_2024.csv")
)

write_csv(
  covid_change,
  here("results", "covid_period_changes.csv")
)







